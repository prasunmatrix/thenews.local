
$(document).ready(function(){      
    'use strict'	
    
    $('body').scrollspy({ target: '#chaps' })
    
    
}); 